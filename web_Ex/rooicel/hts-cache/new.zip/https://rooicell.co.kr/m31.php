<!DOCTYPE html>
<!--[if lt IE 7 ]> <html class="ie6" lang="ko"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie7" lang="ko"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8" lang="ko"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9" lang="ko"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="ko"> <!--<![endif]-->
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"/>
<meta name="format-detection" content="telephone=no, address=no, email=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title>
	OEM/ODM | 루이셀</title>
<!--[if lt IE 9]>
<script src="/js/html5shiv.js"></script>
<![endif]-->
<meta name="Robots" content="all" />
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta property="og:description" content="" />
<meta property="og:image" content="" />
<meta name="Author" content="DESIGNPIXEL" />
<meta name="Copyright" content="(c)DESIGNPIXEL" />
<meta name="publisher" content="DESIGNPIXEL">
<meta name="reply-to" content="" />
<meta name="date" content="" />
<!-- jquery -->
<script src="/js/jquery-1.11.3.min.js"></script>
<script src="/js/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript" src="/js/jquery.easing.1.3.js"></script>
<!-- slick -->
<script type="text/javascript" src="/js/slick.min.js"></script>
<link rel="stylesheet" type="text/css" href="/css/slick.css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css" />
<!-- 공통 css/js -->
<script src="/js/common.js"></script>
<link rel="stylesheet" type="text/css" href="/css/common.css?v=20220128" />
<script src="/js/style.js?v=20220128"></script>
<link rel="stylesheet" type="text/css" href="/css/style_pc.css?v=20220128" media="screen and (min-width:1280px)" />
<link rel="stylesheet" type="text/css" href="/css/style_tablet.css?v=20220128" media="screen and (min-width:768px) and (max-width:1279px)" />
<link rel="stylesheet" type="text/css" href="/css/style_mobile.css?v=20220128" media="screen and (max-width:767px)" />
<link rel="stylesheet" type="text/css" href="/css/locomotive-scroll.css" />
<script src="/js/lodash.min.js"></script>
<script nomodule src="https://cdnjs.cloudflare.com/ajax/libs/babel-polyfill/7.6.0/polyfill.min.js" crossorigin="anonymous"></script>
<script nomodule src="https://polyfill.io/v3/polyfill.min.js?features=Object.assign%2CElement.prototype.append%2CNodeList.prototype.forEach%2CCustomEvent%2Csmoothscroll" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.8.0/ScrollTrigger.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.8.0/gsap.min.js"></script>
<script src="/js/locomotive-scroll.min.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/js/swiper.min.js"></script>

<script>WebFont.load({google: {families: ['Noto Sans KR', 'Montserrat']}});</script>
<script type="text/javascript">
$(document).ready(function () {
	if($('html').is('.ie6, .ie7, .ie8, ie9')) {
		$('div.ie_alert_text').show();
		$('div.ie_alert_text').html('현재 사이트는 IE9 미만의 하위브라우저를 지원하지 않습니다. <br />브라우저를 최신 버전으로 <b>업데이트</b>해 주세요.');
	}
});
</script>
</head>
<body class="">



<div id="custom_cursor"><div class="custom_cursor_inner"><div class="custom_cursor_circle"></div></div></div>
<a href="#contents" id="skip-nav" tabIndex="0">본문 바로가기</a>
<!-- 하위 브라우저 지원 불가 알림창 -->
<div class="ie_alert_text"></div>
<div id="bg"></div>

<header id="header" class="dark fix_style" data-scroll-sticky>
	<div class="header_wrap">
		<h1 class="logo">
			<a href="/">
				<span class="blind">logo</span>
				<svg class="svg_logo" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="156.45px" height="23.424px" viewBox="0 0 156.45 23.424" enable-background="new 0 0 156.45 23.424" xml:space="preserve">
<g>
	<g>
		<path fill="#FB3449" d="M43.319,3.463c2.131,2.061,3.466,5.014,3.466,8.296c0,3.279-1.335,6.234-3.466,8.295
			c-2.13-2.061-3.465-5.016-3.465-8.295C39.854,8.477,41.188,5.523,43.319,3.463z"/>
		<g>
			<path class="txt" fill="#FFFFFF" d="M12.375,11.96c2.026,0,4.569-1.544,5.394-3.567c0.619-1.518,0.619-3.104,0.001-4.621
				c-0.823-2.025-3.367-3.57-5.395-3.57H0v0.115v0.086v11.155v0.403v11.154h2.473V11.96h3.168c0.781,0,1.529,0.338,2.082,0.941
				l9.346,10.213h3.05L9.911,11.96H12.375z M2.473,11.557V0.604h7.838c2.338,0,4.557,1.58,5.168,4.046
				c0.235,0.949,0.235,1.913,0,2.861c-0.611,2.466-2.83,4.046-5.168,4.046H2.473z"/>
			<path class="txt" fill="#FFFFFF" d="M61.818,5.236c-0.487-0.621-1.041-1.199-1.654-1.727
				c-0.307-0.264-0.627-0.516-0.961-0.753C58.534,2.281,57.812,1.86,57.045,1.5c-1.919-0.898-4.117-1.408-6.454-1.408
				c-2.336,0-4.535,0.51-6.454,1.408c-0.281,0.132-0.549,0.281-0.818,0.428c-0.268-0.147-0.537-0.296-0.818-0.428
				c-1.918-0.898-4.117-1.408-6.454-1.408c-2.336,0-4.535,0.51-6.454,1.408c-0.767,0.359-1.49,0.781-2.158,1.256
				c-0.334,0.238-0.656,0.489-0.962,0.753c-0.613,0.527-1.167,1.105-1.653,1.727c-0.487,0.62-0.906,1.283-1.248,1.981
				c-0.686,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54c0.342,0.698,0.761,1.361,1.248,1.981
				c0.487,0.621,1.041,1.199,1.653,1.727c0.306,0.264,0.627,0.516,0.962,0.754c0.668,0.475,1.391,0.896,2.158,1.255
				c1.918,0.897,4.117,1.408,6.454,1.408c2.337,0,4.535-0.511,6.454-1.408c0.281-0.132,0.55-0.28,0.818-0.428
				c0.269,0.147,0.537,0.296,0.818,0.428c1.918,0.897,4.117,1.408,6.454,1.408c2.337,0,4.535-0.511,6.454-1.408
				c0.767-0.358,1.489-0.78,2.158-1.255c0.334-0.238,0.655-0.49,0.961-0.754c0.613-0.527,1.167-1.105,1.654-1.727
				c0.486-0.62,0.905-1.283,1.248-1.981c0.686-1.396,1.064-2.93,1.064-4.54v-0.001c0-1.61-0.378-3.145-1.064-4.541
				C62.723,6.52,62.305,5.856,61.818,5.236z M37.148,22.974c-0.364,0.026-0.729,0.048-1.101,0.048s-0.736-0.021-1.1-0.048
				c-5.414-0.578-9.637-5.379-9.637-11.215c0-5.837,4.223-10.637,9.635-11.216c0.364-0.026,0.73-0.048,1.102-0.048
				c0.373,0,0.738,0.021,1.103,0.048c1.895,0.203,3.637,0.932,5.11,2.033c-0.093,0.063-0.191,0.117-0.282,0.181
				c-0.334,0.238-0.655,0.489-0.961,0.753c-0.612,0.527-1.167,1.105-1.653,1.727c-0.487,0.62-0.906,1.283-1.248,1.981
				c-0.686,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54c0.342,0.698,0.761,1.361,1.248,1.981
				c0.486,0.621,1.041,1.199,1.653,1.727c0.306,0.264,0.627,0.516,0.961,0.754c0.09,0.063,0.189,0.118,0.282,0.181
				C40.787,22.042,39.043,22.771,37.148,22.974z M43.319,20.054c-2.13-2.061-3.465-5.016-3.465-8.295
				c0-3.282,1.335-6.235,3.465-8.296c2.131,2.061,3.466,5.014,3.466,8.296C46.785,15.038,45.45,17.993,43.319,20.054z
				 M51.691,22.974c-0.364,0.026-0.729,0.048-1.101,0.048c-0.371,0-0.737-0.021-1.1-0.048c-1.896-0.202-3.639-0.932-5.113-2.032
				c0.092-0.063,0.191-0.118,0.282-0.181c0.334-0.238,0.655-0.49,0.961-0.754c0.613-0.527,1.167-1.105,1.654-1.727
				c0.486-0.62,0.905-1.283,1.248-1.981c0.686-1.396,1.064-2.93,1.064-4.54v-0.001c0-1.61-0.379-3.145-1.064-4.541
				c-0.342-0.698-0.761-1.361-1.248-1.981c-0.487-0.621-1.041-1.199-1.654-1.727c-0.306-0.264-0.627-0.516-0.961-0.753
				c-0.09-0.064-0.189-0.119-0.282-0.181c1.473-1.101,3.216-1.83,5.111-2.033c0.364-0.026,0.73-0.048,1.102-0.048
				c0.372,0,0.738,0.021,1.103,0.048c5.412,0.58,9.635,5.379,9.635,11.216C61.328,17.595,57.104,22.396,51.691,22.974z"/>
			<polygon class="txt" fill="#FFFFFF" points="99.97,0.402 99.971,0.402 99.971,11.356 99.97,11.356 99.97,11.758 
				99.971,11.758 99.971,22.712 99.97,22.712 99.97,23.114 117.783,23.114 117.783,22.712 102.444,22.712 102.444,11.758 
				115.127,11.758 115.127,11.356 102.444,11.356 102.444,0.402 117.783,0.402 117.783,0 99.97,0 			"/>
			<rect class="txt" x="67.031" y="0.201" fill="#FFFFFF" width="2.473" height="23.115"/>
			<polygon class="txt" fill="#FFFFFF" points="122.646,0 120.172,0 120.172,22.712 120.172,22.712 120.172,23.114 
				137.116,23.114 137.116,22.712 122.646,22.712 			"/>
			<polygon class="txt" fill="#FFFFFF" points="141.978,22.712 141.978,0 139.506,0 139.506,22.712 139.506,22.712 
				139.506,23.114 156.45,23.114 156.45,22.712 			"/>
			<path class="txt" fill="#FFFFFF" d="M84.84,0.542c0.365-0.026,0.73-0.048,1.102-0.048c0.373,0,0.739,0.021,1.104,0.048
				c2.917,0.313,5.48,1.858,7.232,4.125h2.398c-0.361-0.405-0.742-0.797-1.159-1.157c-0.308-0.264-0.628-0.516-0.962-0.753
				c-0.67-0.475-1.391-0.896-2.158-1.256c-1.919-0.898-4.117-1.408-6.455-1.408c-2.336,0-4.534,0.51-6.452,1.408
				C78.721,1.86,78,2.281,77.331,2.756c-0.334,0.238-0.655,0.489-0.961,0.753c-0.613,0.527-1.167,1.105-1.654,1.727
				c-0.486,0.62-0.905,1.283-1.248,1.981c-0.685,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54
				c0.343,0.698,0.762,1.361,1.248,1.981c0.487,0.621,1.041,1.199,1.654,1.727c0.306,0.264,0.627,0.516,0.961,0.754
				c0.669,0.475,1.391,0.896,2.159,1.255c1.918,0.897,4.116,1.408,6.452,1.408c2.338,0,4.536-0.511,6.455-1.408
				c0.768-0.358,1.488-0.78,2.158-1.255c0.334-0.238,0.654-0.49,0.962-0.754c0.417-0.361,0.798-0.753,1.159-1.158h-2.398
				c-1.752,2.268-4.316,3.813-7.234,4.125c-0.363,0.026-0.729,0.048-1.102,0.048c-0.37,0-0.736-0.021-1.1-0.048
				c-5.412-0.578-9.637-5.379-9.637-11.215C75.206,5.922,79.428,1.122,84.84,0.542z"/>
		</g>
	</g>
</g>
</svg>
			</a>
		</h1>
		<nav id="nav">
			<ul class="gnb">
				<li class="menu">
					<a href="/m11.php" class="custom_mousemove small_h"><div>BRAND</div></a>
					<div class="lnb sub1">
						<ul class="dep2">
							<li><a href="/m11.php">루이셀</a></li>
							<li><a href="/m12.php">로코블란코</a></li>
							<li><a href="/m13.php">그리앙스</a></li>
						</ul>
					</div><!--lnb-->
				</li>
				<li class="menu">
					<a href="/product.php" class="custom_mousemove small_h"><div>PRODUCTS</div></a>
					<div class="lnb sub2">
						<ul class="dep2">
							<li><a href="/product.php">전체보기</a></li>
							<li><a href="/product.php?cate=1">미백라인</a></li>
							<li><a href="/product.php?cate=2">수분라인</a></li>
							<li><a href="/product.php?cate=3">주름라인</a></li>
							<li><a href="/product.php?cate=4">Special Edition</a></li>
						</ul>
					</div><!--lnb-->
				</li>
				<li class="menu">
					<a href="/m31.php" class="custom_mousemove small_h"><div>OEM/ODM</div></a>
					<div class="lnb sub3">
						<ul class="dep2">
							<li><a href="/m31.php">프로세스</a></li>
							<li><a href="/m32.php">R&D</a></li>
							<li><a href="/m33.php">제조공정</a></li>
							<li><a href="/m34.php">Farm</a></li>
							<li><a href="/m35.php">글로벌네트워크</a></li>
						</ul>
					</div><!--lnb-->
				</li>
				<li class="menu">
					<a href="/m41.php" class="custom_mousemove small_h"><div>CONTACT</div></a>
					<div class="lnb sub4">
						<ul class="dep2">
							<li><a href="/m41.php">Contact</a></li>
						</ul>
					</div><!--lnb-->
				</li>
		</nav>
		<!-- e : nav -->
		<!-- s : group -->
		<div class="group">
			<div class="language">
				<button type="button">KOR</button>
				<ul class="list">
					<li class="on"><a href="/">KOR</a></li>
					<li><a href="/en" target="_blank">ENG</a></li>
					<li><a href="/cn" target="_blank">CHN</a></li>
				</ul>
			</div>
			<button type="button" class="hamburger_btn open custom_mousemove">
				<span></span>
				<span></span>
				<span></span>
			</button>
		</div>
		<!-- e : group -->
	</div>
</header>
	<div id="allmenu">
	<div class="allmenu">
		<button type="button" class="close follow i custom_mousemove"><span class="blind">닫기</span></button>
		<div class="inner">
			<div class="menu_bg">
				<div class="i"><img src="/images/common/allmenu_leaf.png" alt="나뭇잎"></div>
				<div class="bg"></div>
				<div class="slogan">
					<a href="/" class="logo dark custom_mousemove"><svg class="svg_logo" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="156.45px" height="23.424px" viewBox="0 0 156.45 23.424" enable-background="new 0 0 156.45 23.424" xml:space="preserve">
<g>
	<g>
		<path fill="#FB3449" d="M43.319,3.463c2.131,2.061,3.466,5.014,3.466,8.296c0,3.279-1.335,6.234-3.466,8.295
			c-2.13-2.061-3.465-5.016-3.465-8.295C39.854,8.477,41.188,5.523,43.319,3.463z"/>
		<g>
			<path class="txt" fill="#FFFFFF" d="M12.375,11.96c2.026,0,4.569-1.544,5.394-3.567c0.619-1.518,0.619-3.104,0.001-4.621
				c-0.823-2.025-3.367-3.57-5.395-3.57H0v0.115v0.086v11.155v0.403v11.154h2.473V11.96h3.168c0.781,0,1.529,0.338,2.082,0.941
				l9.346,10.213h3.05L9.911,11.96H12.375z M2.473,11.557V0.604h7.838c2.338,0,4.557,1.58,5.168,4.046
				c0.235,0.949,0.235,1.913,0,2.861c-0.611,2.466-2.83,4.046-5.168,4.046H2.473z"/>
			<path class="txt" fill="#FFFFFF" d="M61.818,5.236c-0.487-0.621-1.041-1.199-1.654-1.727
				c-0.307-0.264-0.627-0.516-0.961-0.753C58.534,2.281,57.812,1.86,57.045,1.5c-1.919-0.898-4.117-1.408-6.454-1.408
				c-2.336,0-4.535,0.51-6.454,1.408c-0.281,0.132-0.549,0.281-0.818,0.428c-0.268-0.147-0.537-0.296-0.818-0.428
				c-1.918-0.898-4.117-1.408-6.454-1.408c-2.336,0-4.535,0.51-6.454,1.408c-0.767,0.359-1.49,0.781-2.158,1.256
				c-0.334,0.238-0.656,0.489-0.962,0.753c-0.613,0.527-1.167,1.105-1.653,1.727c-0.487,0.62-0.906,1.283-1.248,1.981
				c-0.686,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54c0.342,0.698,0.761,1.361,1.248,1.981
				c0.487,0.621,1.041,1.199,1.653,1.727c0.306,0.264,0.627,0.516,0.962,0.754c0.668,0.475,1.391,0.896,2.158,1.255
				c1.918,0.897,4.117,1.408,6.454,1.408c2.337,0,4.535-0.511,6.454-1.408c0.281-0.132,0.55-0.28,0.818-0.428
				c0.269,0.147,0.537,0.296,0.818,0.428c1.918,0.897,4.117,1.408,6.454,1.408c2.337,0,4.535-0.511,6.454-1.408
				c0.767-0.358,1.489-0.78,2.158-1.255c0.334-0.238,0.655-0.49,0.961-0.754c0.613-0.527,1.167-1.105,1.654-1.727
				c0.486-0.62,0.905-1.283,1.248-1.981c0.686-1.396,1.064-2.93,1.064-4.54v-0.001c0-1.61-0.378-3.145-1.064-4.541
				C62.723,6.52,62.305,5.856,61.818,5.236z M37.148,22.974c-0.364,0.026-0.729,0.048-1.101,0.048s-0.736-0.021-1.1-0.048
				c-5.414-0.578-9.637-5.379-9.637-11.215c0-5.837,4.223-10.637,9.635-11.216c0.364-0.026,0.73-0.048,1.102-0.048
				c0.373,0,0.738,0.021,1.103,0.048c1.895,0.203,3.637,0.932,5.11,2.033c-0.093,0.063-0.191,0.117-0.282,0.181
				c-0.334,0.238-0.655,0.489-0.961,0.753c-0.612,0.527-1.167,1.105-1.653,1.727c-0.487,0.62-0.906,1.283-1.248,1.981
				c-0.686,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54c0.342,0.698,0.761,1.361,1.248,1.981
				c0.486,0.621,1.041,1.199,1.653,1.727c0.306,0.264,0.627,0.516,0.961,0.754c0.09,0.063,0.189,0.118,0.282,0.181
				C40.787,22.042,39.043,22.771,37.148,22.974z M43.319,20.054c-2.13-2.061-3.465-5.016-3.465-8.295
				c0-3.282,1.335-6.235,3.465-8.296c2.131,2.061,3.466,5.014,3.466,8.296C46.785,15.038,45.45,17.993,43.319,20.054z
				 M51.691,22.974c-0.364,0.026-0.729,0.048-1.101,0.048c-0.371,0-0.737-0.021-1.1-0.048c-1.896-0.202-3.639-0.932-5.113-2.032
				c0.092-0.063,0.191-0.118,0.282-0.181c0.334-0.238,0.655-0.49,0.961-0.754c0.613-0.527,1.167-1.105,1.654-1.727
				c0.486-0.62,0.905-1.283,1.248-1.981c0.686-1.396,1.064-2.93,1.064-4.54v-0.001c0-1.61-0.379-3.145-1.064-4.541
				c-0.342-0.698-0.761-1.361-1.248-1.981c-0.487-0.621-1.041-1.199-1.654-1.727c-0.306-0.264-0.627-0.516-0.961-0.753
				c-0.09-0.064-0.189-0.119-0.282-0.181c1.473-1.101,3.216-1.83,5.111-2.033c0.364-0.026,0.73-0.048,1.102-0.048
				c0.372,0,0.738,0.021,1.103,0.048c5.412,0.58,9.635,5.379,9.635,11.216C61.328,17.595,57.104,22.396,51.691,22.974z"/>
			<polygon class="txt" fill="#FFFFFF" points="99.97,0.402 99.971,0.402 99.971,11.356 99.97,11.356 99.97,11.758 
				99.971,11.758 99.971,22.712 99.97,22.712 99.97,23.114 117.783,23.114 117.783,22.712 102.444,22.712 102.444,11.758 
				115.127,11.758 115.127,11.356 102.444,11.356 102.444,0.402 117.783,0.402 117.783,0 99.97,0 			"/>
			<rect class="txt" x="67.031" y="0.201" fill="#FFFFFF" width="2.473" height="23.115"/>
			<polygon class="txt" fill="#FFFFFF" points="122.646,0 120.172,0 120.172,22.712 120.172,22.712 120.172,23.114 
				137.116,23.114 137.116,22.712 122.646,22.712 			"/>
			<polygon class="txt" fill="#FFFFFF" points="141.978,22.712 141.978,0 139.506,0 139.506,22.712 139.506,22.712 
				139.506,23.114 156.45,23.114 156.45,22.712 			"/>
			<path class="txt" fill="#FFFFFF" d="M84.84,0.542c0.365-0.026,0.73-0.048,1.102-0.048c0.373,0,0.739,0.021,1.104,0.048
				c2.917,0.313,5.48,1.858,7.232,4.125h2.398c-0.361-0.405-0.742-0.797-1.159-1.157c-0.308-0.264-0.628-0.516-0.962-0.753
				c-0.67-0.475-1.391-0.896-2.158-1.256c-1.919-0.898-4.117-1.408-6.455-1.408c-2.336,0-4.534,0.51-6.452,1.408
				C78.721,1.86,78,2.281,77.331,2.756c-0.334,0.238-0.655,0.489-0.961,0.753c-0.613,0.527-1.167,1.105-1.654,1.727
				c-0.486,0.62-0.905,1.283-1.248,1.981c-0.685,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54
				c0.343,0.698,0.762,1.361,1.248,1.981c0.487,0.621,1.041,1.199,1.654,1.727c0.306,0.264,0.627,0.516,0.961,0.754
				c0.669,0.475,1.391,0.896,2.159,1.255c1.918,0.897,4.116,1.408,6.452,1.408c2.338,0,4.536-0.511,6.455-1.408
				c0.768-0.358,1.488-0.78,2.158-1.255c0.334-0.238,0.654-0.49,0.962-0.754c0.417-0.361,0.798-0.753,1.159-1.158h-2.398
				c-1.752,2.268-4.316,3.813-7.234,4.125c-0.363,0.026-0.729,0.048-1.102,0.048c-0.37,0-0.736-0.021-1.1-0.048
				c-5.412-0.578-9.637-5.379-9.637-11.215C75.206,5.922,79.428,1.122,84.84,0.542z"/>
		</g>
	</g>
</g>
</svg>
</a>
					<div class="tit">
						<span>Keep your beauty</span>
						<span>for a long time.</span>
					</div>
				</div>
			</div>
			<div class="all_gnb_wrap">
				<ul class="all_gnb">
					<li class="menu">
						<div class="dep1">
							<div class="title">Brand</div>
						</div>
						<ul class="sub_menu dep2 txt1">
							<li><a href="/m11.php">루이셀</a></li>
							<li><a href="/m12.php">로코블란코</a></li>
							<li><a href="/m13.php">그리앙스</a></li>
						</ul>
					</li>
					<li class="menu">
						<div class="dep1">
							<div class="title">Products</div>
						</div>
						<ul class="sub_menu dep2 txt1">
							<li><a href="/product.php">전체보기</a></li>
							<li><a href="/product.php?cate=1">미백라인</a></li>
							<li><a href="/product.php?cate=2">수분라인</a></li>
							<li><a href="/product.php?cate=3">주름라인</a></li>
							<li><a href="/product.php?cate=4">Special Edition</a></li>
						</ul>
					</li>
					<li class="menu">
						<div class="dep1">
							<div class="title">OEM/ODM</div>
						</div>
						<ul class="sub_menu dep2 txt1">
							<li><a href="/m31.php">프로세스</a></li>
							<li><a href="/m32.php">R&D</a></li>
							<li><a href="/m33.php">제조공정</a></li>
							<li><a href="/m34.php">Farm</a></li>
							<li><a href="/m35.php">글로벌네트워크</a></li>
						</ul>
					</li>
					<li class="menu">
						<div class="dep1">
							<div class="title">Contact</div>
						</div>
						<ul class="sub_menu dep2 txt1">
							<li><a href="/m41.php">Contact</a></li>
						</ul>
					</li>
				</ul>
			</div><!-- all_gnb_wrap -->
		</div>
	</div>
</div><div id="wrap" class="page_scroll_wrap ">
<!-- //header -->		
<div id="container" data-scroll>
<div id="contents">
<main role="main">
<div id="subtop" class="sub_top_wrap st3 st31 ani" data-scroll>
		<div class="sub_bg"><div class="img" data-scroll data-scroll-delay="0.2"></div></div>
		<div class="location_wrap con-width1 ani" data-scroll>
		<div class="inner">
			<button type="button" class="btn custom_mousemove">프로세스 <span class="arr"></span></button>
			<div class="location_list">
				<ul>
										<li><a href="/m31.php">프로세스</a></li>
					<li><a href="/m32.php">R&D</a></li>
					<li><a href="/m33.php">제조공정</a></li>
					<li><a href="/m34.php">Farm</a></li>
					<li><a href="/m35.php">글로벌네트워크</a></li>
									</ul>
			</div>
		</div>
	</div><!-- location_wrap -->
		<div class="title_wrap con-width1">
		<div id="page_title" class="page_title"><div>Process</div></div>
	</div>
	</div><!-- sub_top --><div id="main" class="m00 m30 m31">
	<section class="section sec1">
		<div class="con-width2 inner">
			<div class="process_title fade_ani" data-scroll data-scroll-speed="1" data-scroll-delay="0.2">Process</div>
			<div class="process_list fade_ani2" data-scroll>
				<div class="g" data-scroll data-scroll-speed="1" data-scroll-delay="0.2">
					<div class="item" data-scroll>
						<div class="img" data-scroll><span style="background:url('/images/page/process_bg1.jpg')no-repeat center/cover;"></span></div>
						<div class="text fade_ani" data-scroll>
							<div class="tit">Beauty Convention Center</div>
							<p class="txt1">K뷰티를 선도하는 뷰티컨벤션센터</p>
						</div>
					</div>
					<div class="item" data-scroll>
						<div class="img" data-scroll><span style="background:url('/images/page/process_bg3.jpg')no-repeat center/cover;"></span></div>
						<div class="text fade_ani" data-scroll>
							<div class="tit">Manufacturing Facility</div>
							<p class="txt1">IS022716 인증인 국제 GMP 제조시설</p>
						</div>
					</div>
				</div>
				<div class="g" data-scroll data-scroll-speed="-1" data-scroll-delay="0.2">
					<div class="item" data-scroll>
						<div class="img" data-scroll><span style="background:url('/images/page/process_bg2.jpg')no-repeat center/cover;"></span></div>
						<div class="text fade_ani" data-scroll>
							<div class="tit">Dermatology laboratory & <br>Biomedical Research Institute</div>
							<p class="txt1">우수한 신소재 제품개발</p>
						</div>
					</div>
					<div class="item" data-scroll>
						<div class="img" data-scroll><span style="background:url('/images/page/process_bg4.jpg')no-repeat center/cover;"></span></div>
						<div class="text fade_ani" data-scroll>
							<div class="tit">Natural Ingredients farm</div>
							<p class="txt1">천연원료 자체 농장</p>
						</div>
					</div>
				</div>
			</div>
			<div class="bg"><img src="/images/page/rooicell_logo_bg.png" alt="루이셀 로고"></div>
		</div>
	</section> <!-- section -->
	
	<section class="section sec3 dark">
		<div class="con-width2 inner">
			<div class="sec_title_g">
				<div class="title">OEM 개발프로세스</div>
				<p class="txt1">
				OEM(Original Equipment Manufaturing)란 아웃소싱(Outsourching)으로 고객 요구사항에 적합한 체형 개발과 <br>
				원하는 디자인을 제공 받아 고객의 상표를 부착한 완제품을 생산/납품하는 방식입니다.
				</p>
			</div><!-- sec_title_g -->
			<div class="scroll_x">
				<ol class="list_wrap list_layout1" data-scroll>
					<li>
						<div class="icon"><img src="/images/page/process_icon1.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">01</div>
							<div class="tit">고객상담</div>
						</div>
					</li>
					<li>
						<div class="icon"><img src="/images/page/process_icon3.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">02</div>
							<div class="tit">샘플작업</div>
						</div>
					</li>
					<li>
						<div class="icon"><img src="/images/page/process_icon4.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">03</div>
							<div class="tit">평가</div>
						</div>
					</li>
					<li>
						<div class="icon"><img src="/images/page/process_icon5.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">04</div>
							<div class="tit">부자재, 디자인 제안</div>
						</div>
					</li>
					<li>
						<div class="icon"><img src="/images/page/process_icon6.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">05</div>
							<div class="tit">발주 및 생산</div>
						</div>
					</li>
					<li>
						<div class="icon"><img src="/images/page/process_icon7.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">06</div>
							<div class="tit">납품</div>
						</div>
					</li>
				</ol>
			</div>
		</div>
	</section> <!-- section -->
	<section class="section sec2">
		<div class="con-width2 inner">
			<div class="sec_title_g">
				<div class="title">ODM 개발프로세스</div>
				<p class="txt1">
					ODM(Original Design Manufaturing)란 OEM 방식의 진보된 형태입니다. <br>
					상품기획 · 개발 · 생산 · 품질관리 · 출하까지 전 과정에 대한 토탈 서비스를 실현한 생산방식으로 20년의 LT의 독자 기술력과 노하우가 함께합니다.
				</p>
			</div><!-- sec_title_g -->
			<div class="scroll_x">
				<ol class="list_wrap list_layout1" data-scroll>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon1.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">01</div>
							<div class="tit">고객상담</div>
						</div>
					</li>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon2.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">02</div>
							<div class="tit">기획</div>
						</div>
					</li>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon3.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">03</div>
							<div class="tit">샘플작업</div>
						</div>
					</li>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon4.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">04</div>
							<div class="tit">평가</div>
						</div>
					</li>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon5.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">05</div>
							<div class="tit">부자재, 디자인 제안</div>
						</div>
					</li>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon6.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">06</div>
							<div class="tit">발주 및 생산</div>
						</div>
					</li>
					<li data-scroll>
						<div class="icon"><img src="/images/page/process_icon7.png" alt="루이셀 개발프로세스 아이콘"></div>
						<div class="text">
							<div class="num">07</div>
							<div class="tit">납품</div>
						</div>
					</li>
				</ol>
			</div>
		</div>
	</section> <!-- section -->
</div> <!-- m00 -->

<div id="scroll_wrap" class="up"  data-scroll data-scroll-sticky data-scroll-target="#container">
	<a href="#wrap" data-scroll-to>
		<div class="icon">
			<div class="arrow_area">
				<span>
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
						 y="0px" width="55px" height="55px" viewBox="0 0 55 55" enable-background="new 0 0 55 55" xml:space="preserve">
					<g>
						<g>
							<path fill="none" stroke="#ffffff" stroke-miterlimit="10" d="M27.063,20.201c0,3.173-2.574,5.746-5.746,5.746"/>
							<path fill="none" stroke="#ffffff" stroke-miterlimit="10" d="M27.021,20.201c0,3.173,2.572,5.746,5.746,5.746"/>
						</g>
						<line fill="none" stroke="#ffffff" stroke-miterlimit="10" x1="27.041" y1="34.799" x2="27.041" y2="20.201"/>
					</g>
					</svg>
					<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px"
						 y="0px" width="55px" height="55px" viewBox="0 0 55 55" enable-background="new 0 0 55 55" xml:space="preserve">
					<g>
						<g>
							<path fill="none" stroke="#ffffff" stroke-miterlimit="10" d="M27.063,20.201c0,3.173-2.574,5.746-5.746,5.746"/>
							<path fill="none" stroke="#ffffff" stroke-miterlimit="10" d="M27.021,20.201c0,3.173,2.572,5.746,5.746,5.746"/>
						</g>
						<line fill="none" stroke="#ffffff" stroke-miterlimit="10" x1="27.041" y1="34.799" x2="27.041" y2="20.201"/>
					</g>
					</svg>
				</span>
			</div>
		</div>
	</a>
</div>
</main>
</div><!--//container-->
</div><!--//contents -->
<footer>
	<div class="foot_area1">
		<div class="inner">
			<div class="logo">
				<svg class="svg_logo" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="156.45px" height="23.424px" viewBox="0 0 156.45 23.424" enable-background="new 0 0 156.45 23.424" xml:space="preserve">
<g>
	<g>
		<path fill="#FB3449" d="M43.319,3.463c2.131,2.061,3.466,5.014,3.466,8.296c0,3.279-1.335,6.234-3.466,8.295
			c-2.13-2.061-3.465-5.016-3.465-8.295C39.854,8.477,41.188,5.523,43.319,3.463z"/>
		<g>
			<path class="txt" fill="#FFFFFF" d="M12.375,11.96c2.026,0,4.569-1.544,5.394-3.567c0.619-1.518,0.619-3.104,0.001-4.621
				c-0.823-2.025-3.367-3.57-5.395-3.57H0v0.115v0.086v11.155v0.403v11.154h2.473V11.96h3.168c0.781,0,1.529,0.338,2.082,0.941
				l9.346,10.213h3.05L9.911,11.96H12.375z M2.473,11.557V0.604h7.838c2.338,0,4.557,1.58,5.168,4.046
				c0.235,0.949,0.235,1.913,0,2.861c-0.611,2.466-2.83,4.046-5.168,4.046H2.473z"/>
			<path class="txt" fill="#FFFFFF" d="M61.818,5.236c-0.487-0.621-1.041-1.199-1.654-1.727
				c-0.307-0.264-0.627-0.516-0.961-0.753C58.534,2.281,57.812,1.86,57.045,1.5c-1.919-0.898-4.117-1.408-6.454-1.408
				c-2.336,0-4.535,0.51-6.454,1.408c-0.281,0.132-0.549,0.281-0.818,0.428c-0.268-0.147-0.537-0.296-0.818-0.428
				c-1.918-0.898-4.117-1.408-6.454-1.408c-2.336,0-4.535,0.51-6.454,1.408c-0.767,0.359-1.49,0.781-2.158,1.256
				c-0.334,0.238-0.656,0.489-0.962,0.753c-0.613,0.527-1.167,1.105-1.653,1.727c-0.487,0.62-0.906,1.283-1.248,1.981
				c-0.686,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54c0.342,0.698,0.761,1.361,1.248,1.981
				c0.487,0.621,1.041,1.199,1.653,1.727c0.306,0.264,0.627,0.516,0.962,0.754c0.668,0.475,1.391,0.896,2.158,1.255
				c1.918,0.897,4.117,1.408,6.454,1.408c2.337,0,4.535-0.511,6.454-1.408c0.281-0.132,0.55-0.28,0.818-0.428
				c0.269,0.147,0.537,0.296,0.818,0.428c1.918,0.897,4.117,1.408,6.454,1.408c2.337,0,4.535-0.511,6.454-1.408
				c0.767-0.358,1.489-0.78,2.158-1.255c0.334-0.238,0.655-0.49,0.961-0.754c0.613-0.527,1.167-1.105,1.654-1.727
				c0.486-0.62,0.905-1.283,1.248-1.981c0.686-1.396,1.064-2.93,1.064-4.54v-0.001c0-1.61-0.378-3.145-1.064-4.541
				C62.723,6.52,62.305,5.856,61.818,5.236z M37.148,22.974c-0.364,0.026-0.729,0.048-1.101,0.048s-0.736-0.021-1.1-0.048
				c-5.414-0.578-9.637-5.379-9.637-11.215c0-5.837,4.223-10.637,9.635-11.216c0.364-0.026,0.73-0.048,1.102-0.048
				c0.373,0,0.738,0.021,1.103,0.048c1.895,0.203,3.637,0.932,5.11,2.033c-0.093,0.063-0.191,0.117-0.282,0.181
				c-0.334,0.238-0.655,0.489-0.961,0.753c-0.612,0.527-1.167,1.105-1.653,1.727c-0.487,0.62-0.906,1.283-1.248,1.981
				c-0.686,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54c0.342,0.698,0.761,1.361,1.248,1.981
				c0.486,0.621,1.041,1.199,1.653,1.727c0.306,0.264,0.627,0.516,0.961,0.754c0.09,0.063,0.189,0.118,0.282,0.181
				C40.787,22.042,39.043,22.771,37.148,22.974z M43.319,20.054c-2.13-2.061-3.465-5.016-3.465-8.295
				c0-3.282,1.335-6.235,3.465-8.296c2.131,2.061,3.466,5.014,3.466,8.296C46.785,15.038,45.45,17.993,43.319,20.054z
				 M51.691,22.974c-0.364,0.026-0.729,0.048-1.101,0.048c-0.371,0-0.737-0.021-1.1-0.048c-1.896-0.202-3.639-0.932-5.113-2.032
				c0.092-0.063,0.191-0.118,0.282-0.181c0.334-0.238,0.655-0.49,0.961-0.754c0.613-0.527,1.167-1.105,1.654-1.727
				c0.486-0.62,0.905-1.283,1.248-1.981c0.686-1.396,1.064-2.93,1.064-4.54v-0.001c0-1.61-0.379-3.145-1.064-4.541
				c-0.342-0.698-0.761-1.361-1.248-1.981c-0.487-0.621-1.041-1.199-1.654-1.727c-0.306-0.264-0.627-0.516-0.961-0.753
				c-0.09-0.064-0.189-0.119-0.282-0.181c1.473-1.101,3.216-1.83,5.111-2.033c0.364-0.026,0.73-0.048,1.102-0.048
				c0.372,0,0.738,0.021,1.103,0.048c5.412,0.58,9.635,5.379,9.635,11.216C61.328,17.595,57.104,22.396,51.691,22.974z"/>
			<polygon class="txt" fill="#FFFFFF" points="99.97,0.402 99.971,0.402 99.971,11.356 99.97,11.356 99.97,11.758 
				99.971,11.758 99.971,22.712 99.97,22.712 99.97,23.114 117.783,23.114 117.783,22.712 102.444,22.712 102.444,11.758 
				115.127,11.758 115.127,11.356 102.444,11.356 102.444,0.402 117.783,0.402 117.783,0 99.97,0 			"/>
			<rect class="txt" x="67.031" y="0.201" fill="#FFFFFF" width="2.473" height="23.115"/>
			<polygon class="txt" fill="#FFFFFF" points="122.646,0 120.172,0 120.172,22.712 120.172,22.712 120.172,23.114 
				137.116,23.114 137.116,22.712 122.646,22.712 			"/>
			<polygon class="txt" fill="#FFFFFF" points="141.978,22.712 141.978,0 139.506,0 139.506,22.712 139.506,22.712 
				139.506,23.114 156.45,23.114 156.45,22.712 			"/>
			<path class="txt" fill="#FFFFFF" d="M84.84,0.542c0.365-0.026,0.73-0.048,1.102-0.048c0.373,0,0.739,0.021,1.104,0.048
				c2.917,0.313,5.48,1.858,7.232,4.125h2.398c-0.361-0.405-0.742-0.797-1.159-1.157c-0.308-0.264-0.628-0.516-0.962-0.753
				c-0.67-0.475-1.391-0.896-2.158-1.256c-1.919-0.898-4.117-1.408-6.455-1.408c-2.336,0-4.534,0.51-6.452,1.408
				C78.721,1.86,78,2.281,77.331,2.756c-0.334,0.238-0.655,0.489-0.961,0.753c-0.613,0.527-1.167,1.105-1.654,1.727
				c-0.486,0.62-0.905,1.283-1.248,1.981c-0.685,1.396-1.064,2.93-1.064,4.541v0.001c0,1.61,0.379,3.145,1.064,4.54
				c0.343,0.698,0.762,1.361,1.248,1.981c0.487,0.621,1.041,1.199,1.654,1.727c0.306,0.264,0.627,0.516,0.961,0.754
				c0.669,0.475,1.391,0.896,2.159,1.255c1.918,0.897,4.116,1.408,6.452,1.408c2.338,0,4.536-0.511,6.455-1.408
				c0.768-0.358,1.488-0.78,2.158-1.255c0.334-0.238,0.654-0.49,0.962-0.754c0.417-0.361,0.798-0.753,1.159-1.158h-2.398
				c-1.752,2.268-4.316,3.813-7.234,4.125c-0.363,0.026-0.729,0.048-1.102,0.048c-0.37,0-0.736-0.021-1.1-0.048
				c-5.412-0.578-9.637-5.379-9.637-11.215C75.206,5.922,79.428,1.122,84.84,0.542z"/>
		</g>
	</g>
</g>
</svg>
			</div>
			<div class="info">
				<div class="list">
					<div>(주)라이프투게더</div>
					<div>회장 : 송운서</div>
				</div>
				<div class="list">
					<div>사업자등록번호 : 221-81-16850</div>
					<div>통신판매업 신고번호 : 제 2004-50호</div>
				</div>
				<div class="list">
					<div>주소 : 강원도 춘천시 공단로 13 (후평동)  / 서울 성동구 연무장5가길 7, 510호(현대테라스타워)</div>
				</div>
				<div class="list">
					<div>제품문의 : 1577-4590</div>
					<div>FAX : 033-243-4780</div>
					<div>E-mail : rooicell@lifetogether.co.kr</div>
				</div>
			</div>
			<ul class="sns_list">
				<li class="follow i custom_mousemove small_h"><a href="https://smartstore.naver.com/rooicell" target="_blank"><img src="/images/common/footer_sns_b.png" alt="네이버블로그 아이콘"></a></li>
				<li class="follow i custom_mousemove small_h"><a href="https://www.facebook.com/Rooicell.kr/?locale=ko_KR" target="_blank"><img src="/images/common/footer_sns_f.png" alt="페이스북 아이콘"></a></li>
				<li class="follow i custom_mousemove small_h"><a href="https://www.youtube.com/@rooicell" target="_blank"><img src="/images/common/footer_sns_y.png" alt="유튜브 아이콘"></a></li>
				<li class="follow i custom_mousemove small_h"><a href="https://www.instagram.com/rooicell_korea/?hl=ko" target="_blank"><img src="/images/common/footer_sns_i.png" alt="인스타그램 아이콘"></a></li>
			</ul>
		</div>
	</div>
	<div class="foot_area2">
		<div class="inner">
			<div class="g">
				<p class="copyright">Copyright © 2022 LIFETOGETHER CO.,LTDAll Rights Reserved.</p>
			</div>
		</div>
	</div>
</footer>
<!--//footer-->
<script>
	$(function(){
		gsap.registerPlugin(ScrollTrigger);
		

		const locoScroll= new LocomotiveScroll({
			el: document.querySelector('.page_scroll_wrap'),
			smooth: true,
			smoothMobile: true,
			//getDirection: true,
			paused: true,
			onUpdate: () => {
			  window.dispatchEvent(new Event('resize'));
			},
			multiplier:1,
			smartphone: {
				smooth: true
			},
			tablet: {
				smooth: true
			},
			//getSpeed: true,
		   useKeyboard: true,
			//reloadOnContextChange: true
		});

		var lastScrollTop = 0;
		var delta = 0;
		locoScroll.on('scroll', (position) => {

		function productsViewThumb(){
		if(!$('#main').hasClass('products_view_wrap')) return;
			var scrollDistance = position.scroll.y;
			$('.product_gallery_big .img').each(function(i) {
				if ($(this).position().top < (position.scroll.y)) {
					$('.product_gallery_nav ul li').removeClass('active');
					$('.product_gallery_nav ul li').eq(i).addClass('active');
				}
			});
		}
		productsViewThumb();
					
		  if ((position.scroll.y) > delta) {
			document.querySelector('body').classList.add('active');
			document.querySelector('header').classList.add('active');
		  } else {
			document.querySelector('body').classList.remove('active');
			document.querySelector('header').classList.remove('active');
		  }

			var scrollT=position.scroll.y;
			if(Math.abs(lastScrollTop - scrollT) <= delta)
			return; 
			if ((scrollT > lastScrollTop) && (lastScrollTop>90)) {
			$('header').addClass('hide');
			
			} else {
			$('header').removeClass('hide');
			
			}
			lastScrollTop = scrollT;
			if($('header:not(.fix_style)').hasClass('hide')){
				$('header nav').fadeOut(200);
			}else{
				$('header nav').fadeIn(300);
			}
		});
		
		locoScroll.on("scroll", ScrollTrigger.update);

		ScrollTrigger.scrollerProxy(".page_scroll_wrap", {
			scrollTop(value) {
				return arguments.length
					? locoScroll.scrollTo(value, 0, 0)
					: locoScroll.scroll.instance.scroll.y;
			},
			getBoundingClientRect() {
				return {
					top: 0,
					left: 0,
					width: window.innerWidth,
					height: window.innerHeight
				};
			},
			pinType: document.querySelector('.page_scroll_wrap').style.transform ? "transform" : "fixed"
		});


		
		gsap.to("body.pc #subtop .sub_bg .img", {
		  scrollTrigger: {
			trigger: "#subtop",
			scroller: ".page_scroll_wrap",
			scrub: true,
			start: "+=-10%",
			end: "+=140%",
		  },
		backgroundPosition:'55% -90%',
		});
		gsap.to("body:not(.pc) #subtop .sub_bg .img", {
		  scrollTrigger: {
			trigger: "#subtop",
			scroller: ".page_scroll_wrap",
			scrub: true,
			start: "0%",
			end: "+=140%",
		  },
		y:'30%',
		});
			


		ScrollTrigger.addEventListener("refresh", () => locoScroll.update());
		ScrollTrigger.refresh();



		function pageLayoutStyle2(){
			if(!$('#main').hasClass('products_view_wrap')) return;
			$(document).on("click",".product_aside ul .group",function(e){
				window.dispatchEvent(new Event('resize'));
				$(this).toggleClass("act");
				if($(this).hasClass("act")){
					$(this).find(".view").stop(true,true).show();
					tl.staggerFromTo($(".product_aside ul .group .view .textarea"), 0.7, {opacity:0}, {opacity: 1, ease: Power1.easeInOut});
				}else{
					$(this).find(".view").stop(true,true).hide();
				}
				$(this).siblings().removeClass("act");
				$(this).siblings().find(".view").stop(true,true).hide();
			});
		}
	
		pageLayoutStyle2();

	});
</script></div><!--//wrap-->
<div id="video-popup"></div>
</body>
</html>